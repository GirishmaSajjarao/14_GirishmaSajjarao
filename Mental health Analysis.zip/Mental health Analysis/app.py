import streamlit as st
import pickle

model = pickle.load(open("model.pkl", "rb"))
vectorizer = pickle.load(open("vectorizer.pkl", "rb"))

st.set_page_config(page_title="Mental Health AI", layout="centered")

st.title("🧠 AI Mental Health Triage System")
st.caption("⚠️ Not a medical diagnosis. This tool provides supportive guidance only.")

user_input = st.text_area("💬 Enter how you are feeling:")

def get_response(label, text):
    if label == 0:
        return "🟢 **Low Risk**\n\nYour message shows normal emotional expression. Keep taking care of yourself 😊"
    elif label == 1:
        return "🟡 **Medium Risk**\n\nYour text indicates stress or anxiety. Consider talking to someone you trust and practicing self-care."
    else:
        return "🔴 **High Risk**\n\nYour message shows signs of emotional distress.\n\nPlease consider reaching out to a mental health professional or a trusted person immediately.\n\n📞 *If this is urgent, seek local help or helplines.*"

if st.button("Analyze"):
    if user_input.strip() == "":
        st.warning("Please enter some text.")
    else:
        vec = vectorizer.transform([user_input])
        prediction = model.predict(vec)[0]

        st.markdown(get_response(prediction, user_input))
